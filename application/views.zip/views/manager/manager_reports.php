<!-- begin:: Content -->
						<div class="kt-container  kt-container--fluid  kt-grid__item kt-grid__item--fluid">
							<div class="row">
								<div class="col">
									<div class="alert alert-light alert-elevate fade show" role="alert">
										<div class="alert-icon"><i class="flaticon-warning kt-font-brand"></i></div>
										<div class="alert-text">
											Google chart tools are powerful, simple to use, and free. For more info please visit the plugin's <a class="kt-link kt-font-bold" href="https://google-developers.appspot.com/chart/interactive/docs/quick_start" target="_blank">Demo Page</a>.
										</div>
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-lg-6">

									<!--begin::Portlet-->
									<div class="kt-portlet kt-portlet--tab">
										<div class="kt-portlet__head">
											<div class="kt-portlet__head-label">
												<span class="kt-portlet__head-icon kt-hidden">
													<i class="la la-gear"></i>
												</span>
												<h3 class="kt-portlet__head-title">
													Column Chart 1
												</h3>
											</div>
										</div>
										<div class="kt-portlet__body">
											<div id="kt_gchart_1" style="height:500px;"></div>
										</div>
									</div>

									<!--end::Portlet-->
								</div>
								<div class="col-lg-6">

									<!--begin::Portlet-->
									<div class="kt-portlet kt-portlet--tab">
										<div class="kt-portlet__head">
											<div class="kt-portlet__head-label">
												<span class="kt-portlet__head-icon kt-hidden">
													<i class="la la-gear"></i>
												</span>
												<h3 class="kt-portlet__head-title">
													Column Chart 2
												</h3>
											</div>
										</div>
										<div class="kt-portlet__body">
											<div id="kt_gchart_2" style="height:500px;"></div>
										</div>
									</div>

									<!--end::Portlet-->
								</div>
							</div>
							<div class="row">
								<div class="col-lg-6">

									<!--begin::Portlet-->
									<div class="kt-portlet kt-portlet--tab">
										<div class="kt-portlet__head">
											<div class="kt-portlet__head-label">
												<span class="kt-portlet__head-icon kt-hidden">
													<i class="la la-gear"></i>
												</span>
												<h3 class="kt-portlet__head-title">
													Pie Chart 1
												</h3>
											</div>
										</div>
										<div class="kt-portlet__body">
											<div id="kt_gchart_3" style="height:500px;"></div>
										</div>
									</div>

									<!--end::Portlet-->
								</div>
								<div class="col-lg-6">

									<!--begin::Portlet-->
									<div class="kt-portlet kt-portlet--tab">
										<div class="kt-portlet__head">
											<div class="kt-portlet__head-label">
												<span class="kt-portlet__head-icon kt-hidden">
													<i class="la la-gear"></i>
												</span>
												<h3 class="kt-portlet__head-title">
													Pie Chart 2
												</h3>
											</div>
										</div>
										<div class="kt-portlet__body">
											<div id="kt_gchart_4" style="height:500px;"></div>
										</div>
									</div>

									<!--end::Portlet-->
								</div>
							</div>
							<div class="row">
								<div class="col-lg-12">

									<!--begin::Portlet-->
									<div class="kt-portlet kt-portlet--tab">
										<div class="kt-portlet__head">
											<div class="kt-portlet__head-label">
												<span class="kt-portlet__head-icon kt-hidden">
													<i class="la la-gear"></i>
												</span>
												<h3 class="kt-portlet__head-title">
													Line Chart 1
												</h3>
											</div>
										</div>
										<div class="kt-portlet__body">
											<div id="kt_gchart_5" style="height:500px;"></div>
										</div>
									</div>

									<!--end::Portlet-->
								</div>
							</div>
						</div>

						<!-- end:: Content -->
					</div>
