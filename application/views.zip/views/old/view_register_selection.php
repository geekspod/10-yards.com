<!DOCTYPE html>
<html>

<section class="chose-opt-banner container">
	<div class="inner">
		<div class="sg-heading">
			<h3>Register</h3>
		</div>
		<div class="chef-form">
			<div class="row">
				<div class="col-md-12">
					<a href="<?php echo base_url() ; ?>register/index/employer" class="btn btn-primary btn-lg">Register as Employer </a>
					<a href="<?php echo base_url() ; ?>register/employee"  class="btn btn-primary btn-lg"> Register as Employee</a>
				</div>
			</div>
			
		</div>
	</div>
</section>
