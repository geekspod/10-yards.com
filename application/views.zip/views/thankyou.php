 
<section class="subscription-cancel" style="text-align:center; background:orange">
	<div class="container">
	<div class="subscription-cancel-data">
	<!--    <h5>Thank you for your Registration!</h5>-->
	<!--<p>Kindly check your Email Inbox/Junk for confirmation link </p>-->
	
	<h1 style="padding:50px 0px">Thank you for your Registration!</h1>
	<p>Kindly check your Email Inbox/Junk for confirmation link </p>
	<a href="<?php echo base_url() ; ?>login"> LOGIN </a> / <a href="<?php echo base_url() ; ?>"> BACK HOME </a>
	</div>
	</div>
</section>