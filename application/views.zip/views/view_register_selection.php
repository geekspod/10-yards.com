<!DOCTYPE html>
<html>

<section class="chose-opt-banner container" style="color:white;background: #333; margin:0px; padding:97px 0px">
	<div class="inner">
		<div class="sg-heading">
			<h3 style="font-size:40px; font-weight:bold">Register</h3>
		</div>
		<div class="chef-form" style="text-align:center;margin: 0 auto">
			<div class="row" style="padding:0px; margin:0px">
				<div class="col-md-12">
					<a href="<?php echo base_url() ; ?>register/index/employer" class="btn btn-primary btn-lg">Register as Employer </a>
					<a href="<?php echo base_url() ; ?>register/employee"  class="btn btn-primary btn-lg"> Register as Employee</a>
				</div>
			</div>
			
		</div>
	</div>
</section>
