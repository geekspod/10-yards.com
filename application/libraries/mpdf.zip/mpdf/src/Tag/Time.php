<?php

namespace Mpdf\Tag;

class Time extends InlineTag
{


}
